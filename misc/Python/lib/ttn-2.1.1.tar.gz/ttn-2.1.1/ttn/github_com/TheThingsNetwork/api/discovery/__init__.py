from .discovery_pb2 import *
from .discovery_pb2_grpc import *
